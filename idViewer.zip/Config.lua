return {
    TOOL_NAME = "Phone",
    PASSCODE = "2006",
    CLONE_BATCH_SIZE = 5,
    CLONE_DELAY = 6,
    REMOTE_PATH = "Remotes.Command.CommandEvent",
    ALLOWED_PLACE_IDS = {133943904733338, 7041939546},
    DEVELOPER_USERNAME = "AlfreadR0rw",
    DEVELOPER_USER_ID = 10164114772,
    KEY_TIMER_INTERVAL = 1, -- detik

    BUY_KEY_URL = "https://wa.me/60136951175?text=beli",

    LogoURL = "https://files.catbox.moe/io8o2d.png",
    LogoLocalPath = "PhoneIDViewer_Logo.png",

    DiscordURL = "https://discord.gg/yourdiscord",
    WhatsAppURL = "https://wa.me/6281234567890",
    TelegramURL = "https://t.me/yourusername",

    DiscordIconURL = "https://files.catbox.moe/lgxgw4.jpg",
    WhatsAppIconURL = "https://files.catbox.moe/ef6pfn.jpg",
    TelegramIconURL = "https://files.catbox.moe/ugzz6k.jpg",

    MapNames = {
        [133943904733338] = "Main Game",
        [7041939546] = "Lobby",
        [1818] = "Baseplate",
    },
}